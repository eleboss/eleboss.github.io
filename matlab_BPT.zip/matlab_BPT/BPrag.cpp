#include "BPrag.h"


BPrag::BPrag(void)
{
}


BPrag::~BPrag(void)
{
}
