VectorXf v;
v.setOnes(3);
cout << v << endl;
